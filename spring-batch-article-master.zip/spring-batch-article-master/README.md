# spring-batch-article

Project for the post [Spring Batch Tutorial: Batch Processing Made Easy with Spring](https://www.toptal.com/spring/spring-batch-tutorial) in the Toptal blog
